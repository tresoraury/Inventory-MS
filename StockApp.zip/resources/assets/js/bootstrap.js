window.$ = window.jQuery = require('jquery');
require('materialize-css');