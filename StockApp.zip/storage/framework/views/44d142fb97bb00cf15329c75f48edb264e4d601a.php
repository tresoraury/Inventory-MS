<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'TestApp')); ?></title>
    <!-- Styles -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('css'); ?>
</head>
<body>
    <div id="app">
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            @csrf
        </form>
        <?php if(auth()->guard()->check()): ?>
            <ul id="dropdown1" class="dropdown-content">
                <li><a href="<?php echo e(route('logout')); ?>" class="logout"><?php echo e(__('Logout')); ?></a></li>

            </ul>
        <?php endif; ?>
        <nav>
            <div class="nav-wrapper">
                <a href="<?php echo e(url('/')); ?>" class="brand-logo">retour</a>
                <a href="#" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>
                <?php if(auth()->guard()->guest()): ?>
                    <ul class="right hide-on-med-and-down">
                        <li><a href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a></li>
                        
                    </ul>
                <?php else: ?>
                    <ul class="right hide-on-med-and-down">
                        <li><a class="dropdown-trigger" href="#!" data-target="dropdown1"><?php echo e(Auth::user()->name); ?><i class="material-icons right"></i></a></li>
                    </ul>

                <?php endif; ?>
            </div>
        </nav>
        <ul class="sidenav" id="mobile-demo">
            <?php if(auth()->guard()->guest()): ?>
                <li><a href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a></li>
                <li><a href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a></li>
            <?php else: ?>

                <li><a href="<?php echo e(route('logout')); ?>" class="logout"><?php echo e(__('Logout')); ?></a></li>

            <?php endif; ?>
        </ul>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script>
        $(document).ready(function(){
            $('.sidenav').sidenav();
            $('.dropdown-trigger').dropdown();
            $('.logout').click(function(e) {
                e.preventDefault();
                $('#logout-form').submit();
            });
        });
    </script>
</body>
</html>