<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col s12 m10 offset-m1 l8 offset-l2">
            <div class="card">
            <form  method="POST" action="<?php echo e(route('register')); ?>">
                <div class="card-content">
                    <?php echo e(csrf_field()); ?>

                    <span class="card-title"><?php echo e(__('Register')); ?></span>
                    <hr>
                    <div class="row">
                        <div class="input-field col s12">
                            <i class="material-icons prefix">person</i>
                            <input id="name" type="text" name="name" value="<?php echo e(old('name')); ?>" class="<?php echo e($errors->has('name') ? 'invalid' : ''); ?>" required autofocus>
                            <label for="email"><?php echo e(__('Name')); ?></label>
                            <span class="red-text"><?php echo e($errors->has('name') ? $errors->first('name'): ''); ?></span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s12">
                            <i class="material-icons prefix">mail</i>
                            <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" class="<?php echo e($errors->has('email') ? 'invalid' : ''); ?>" required>
                            <label for="email"><?php echo e(__('E-Mail Address')); ?></label>
                            <span class="red-text"><?php echo e($errors->has('email') ? $errors->first('email'): ''); ?></span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s12">
                            <i class="material-icons prefix">lock</i>
                            <input id="password" type="password" name="password" class="<?php echo e($errors->has('password') ? 'invalid' : ''); ?>" required>
                            <label for="password"><?php echo e(__('Password')); ?></label>
                            <span class="red-text"><?php echo e($errors->has('password') ? $errors->first('password'): ''); ?></span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s12">
                            <i class="material-icons prefix">lock</i>
                            <input id="password-confirm" type="password" name="password_confirmation" required>
                            <label for="password-confirm"><?php echo e(__('Confirm Password')); ?></label>
                        </div>
                    </div>
                    <p>
                        <button class="btn waves-effect waves-light" type="submit" name="action"><?php echo e(__('Register')); ?>

                            <i class="material-icons right">create</i>
                        </button>
                    </p>
                </div>
            </form>
        </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>