<?php $__env->startSection('content'); ?>
<center>
<br><br>
<a href="<?php echo e(url('/prnpriview')); ?>" class="btnprn btn">Print Preview</a></center>
<?php echo e(csrf_field()); ?>

<script type="text/javascript">
$(document).ready(function(){
$('.btnprn').printPage();
});
</script>
<center>
<h1> NOMBRE DISPONIBLE DES PRODUIT DANS LE STOCK </h1>
<table class="table">
<tr><th>id_stock</th><th>id_materiaux</th><th>quantite</th><th>quantite_detaille</th></tr>
 <?php $__currentLoopData = $stock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr><td><?php echo e($data->id_stock); ?></td>
<td><?php echo e($data->id_materiaux); ?></td>
<td><?php echo e($data->quantite); ?></td>
<td><?php echo e($data->quantite_detaille); ?></td> </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>