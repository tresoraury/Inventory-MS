<?php $__env->startSection('title'); ?>
STOCKS REEL Modifier | regideso
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="row">
  	<div class="col-md-12">
            <div class="card">
              <div class="card-header">
              	<h4 class="card-title"> stock - Modifier Data</h4>
                
                <form action="<?php echo e(url('stock-update/'.$stock->id_stock)); ?>" method="POST">
         <?php echo e(csrf_field()); ?>

         <?php echo e(method_field('PUT')); ?>


      <div class="modal-body">
        
        <div class="form-group">
          <label for="recipient-name" class="col-form-label">id_materiaux:</label>
            <input type="text" name="id_materiaux"class="form-control" id="recipient-name" value="<?php echo e($stock->id_materiaux); ?>">
          </div>
          <div class="form-group">
          <label for="recipient-name" class="col-form-label">quantite:</label>
            <input type="text" name="quantite"class="form-control" id="recipient-name" value="<?php echo e($stock->quantite); ?>">
          </div>
          <div class="form-group">
          <label for="recipient-name" class="col-form-label">quantite_detaille:</label>
            <input type="text" name="quantite_detaille"class="form-control" id="recipient-name" value="<?php echo e($stock->quantite_detaille); ?>">
          </div>
          
        <div class="modal-footer">
        <a href="<?php echo e(url('stock')); ?>" class="btn btn-secondary">BACK</a>
        <button type="submit" class="btn btn-primary">MODIFIER</button>
      </div>
  </form>
</div>
</div>
</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>