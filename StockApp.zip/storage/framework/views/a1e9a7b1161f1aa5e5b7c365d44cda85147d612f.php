<center>
<br><br>
<style>
	.card_image{
                 width: 100px;
                 height: 100px;
                 top: 150px;
                 right: 300px;
             }
    td {
    
    border: 1px solid #ddd;
  padding: 15px;
  width: 20px;
  height: 50px;
  }
  th {
    background-color: #4CAF50;
    color: white;
    font-size: 1em;
      }

</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://www.position-absolute.com/creation/print/jquery.printPage.js"></script>
<a href="<?php echo e(url('/prnpriview')); ?>" class="btnprn btn">Print Preview</a></center>
<?php echo e(csrf_field()); ?>

<script type="text/javascript">
$(document).ready(function(){
$('.btnprn').printPage();
});
</script>
<div class="card">
        <img class="card_image" src="photo.jpg" width="200px">
    </div>
<center>
<h1> OPERATION EFFECTUEES </h1>
<table class="table">
<tr><th>id_operation</th><th>materiel_id</th><th>type_operation</th><th>designation</th><th>partenaire</th><th>date_operation</th><th>quantite</th></tr>
 <?php $__currentLoopData = $magasin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr><td><?php echo e($item->id_operation); ?></td>
<td><?php echo e($item->materiel_id); ?></td>
<td><?php echo e($item->type_operation); ?></td>
<td><?php echo e($item->designation); ?></td>
<td><?php echo e($item->partenaire); ?></td>
<td><?php echo e($item->date_operation); ?></td>
<td><?php echo e($item->quantite); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</center>