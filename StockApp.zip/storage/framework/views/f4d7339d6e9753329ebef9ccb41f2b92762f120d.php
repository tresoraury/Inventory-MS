<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if(session('status')): ?>
        <div class="card">
            <div class="card green darken-1">
                <div class="card-content white-text">
                    <?php echo e(session('status')); ?>

                </div>
            </div>
        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col s12 m10 offset-m1 l8 offset-l2">
            <div class="card">
            <form  method="POST" action="<?php echo e(route('password.email')); ?>">
                <div class="card-content">
                    <?php echo e(csrf_field()); ?>

                    <span class="card-title"><?php echo e(__('Reset Password')); ?></span>
                    <hr>
                    <div class="row">
                        <div class="input-field col s12">
                            <i class="material-icons prefix">mail</i>
                            <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" class="<?php echo e($errors->has('email') ? 'invalid' : ''); ?>" required autofocus>
                            <label for="email"><?php echo e(__('E-Mail Address')); ?></label>
                            <span class="red-text"><?php echo e($errors->has('email') ? $errors->first('email'): ''); ?></span>
                        </div>
                    </div>
                    <p>
                        <button class="btn waves-effect waves-light right" type="submit" name="action"><?php echo e(__('Send Password Reset Link')); ?>

                            <i class="material-icons right">lock_open</i>
                        </button>
                    </p>
                    <br><br>
                </div>
            </form>
        </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>