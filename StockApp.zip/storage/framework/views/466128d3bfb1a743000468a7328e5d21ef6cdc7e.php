<?php $__env->startSection('title'); ?>
  Materiaux Edit

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="row">
  	<div class="col-md-12">
            <div class="card">
              <div class="card-header">
              	<h4 class="card-title"> materiaux - Edit Data</h4>
                
                <form action="<?php echo e(url('materiaux-update/'.$materiaux->id)); ?>" method="POST">
         <?php echo e(csrf_field()); ?>

         <?php echo e(method_field('PUT')); ?>


      <div class="modal-body">
        
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">No_code :</label>
            <input type="text" name="No_code"class="form-control" value="<?php echo e($materiaux->No_code); ?>">
          </div>
          <div class="form-group">
          <label for="recipient-name" class="col-form-label">designation :</label>
            <input type="text" name="designation"class="form-control" value="<?php echo e($materiaux->designation); ?>">
          </div>
          <div class="form-group">
          <label for="recipient-name" class="col-form-label">unite_emploie :</label>
            <input type="text" name="unite_emploie"class="form-control" value="<?php echo e($materiaux->unite_emploie); ?>">
          </div>
          <div class="form-group">
          <label for="recipient-name" class="col-form-label">rangement :</label>
            <input type="text" name="rangement"class="form-control" value="<?php echo e($materiaux->rangement); ?>">
          </div>
          <div class="form-group">
          <label for="recipient-name" class="col-form-label">quantite :</label>
            <input type="text" name="quantite"class="form-control" value="<?php echo e($materiaux->quantite); ?>">
          </div>
          
        <div class="modal-footer">
        	<a href="<?php echo e(url('materiaux')); ?>" class="btn btn-secondary">BACK</a>
        <button type="submit" class="btn btn-primary">UPDATE</button>
      </div>
      </div>
      
      </form>
               
               </div>
           </div>
       </div>
</div>



<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>